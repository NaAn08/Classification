# Load the packages and data
library(tidyverse)
library(corrplot)
library(caret)
library(pROC)
library(randomForest)

data <- read.csv("bank_personal_loan.csv")

# Problem description
sapply(data, function(x){sum(is.na(x))})
data <- data[,-4]
data <- data[,c(8,1:7,9:12)]

corrplot.mixed(cor(data), lower = "number", upper = "circle",tl.pos = "lt",
               lower.col = "black", number.cex = .7)

data[,c(1,7,9:12)] <- lapply(data[,c(1,7,9:12)], as.factor)

## numeric
data %>%
  select(c(1:6,8)) %>%
  pivot_longer(-Personal.Loan) %>%
  ggplot(aes(Personal.Loan, value, fill = Personal.Loan)) +
  geom_boxplot() +
  facet_wrap(name~., scale = "free") +
  theme_bw()

## categorical
data %>%
  select(c(1,7,9:12)) %>%
  pivot_longer(-Personal.Loan) %>%
  group_by(Personal.Loan, name, value) %>%
  count() %>%
  ungroup() %>%
  mutate(value = factor(value, levels = 0:4)) %>%
  ggplot(aes(Personal.Loan, n, fill = value)) +
  geom_bar(stat = "identity", position = "fill", width = 0.7) +
  facet_wrap(name~., scale = "free") +
  labs(y = "", fill = "") +
  theme_bw()

# Model fitting
## Split data
set.seed(123)
ind <- createDataPartition(y = data$Personal.Loan,
                           p = 0.7,
                           list = FALSE)
train <- data[ind, ]
test <- data[-ind, ]

## logistic regression model
glm.mod <- train(Personal.Loan~.,
                 train,
                 method = "glm")
glm.prob <- predict(glm.mod, test, type = "prob")[,2]
glm.pred <- predict(glm.mod, test)
glm.cf <- confusionMatrix(glm.pred, test$Personal.Loan)

glm.perf <- round(c(glm.cf$overall[1], glm.cf$byClass[c(1,2,5,6,7)]),2)
knitr::kable(t(as.data.frame(glm.perf)), format = "simple")

## tree model
tree.mod <- train(Personal.Loan~.,
                  train,
                  method = "rpart",
                  tuneGrid = expand.grid(cp = 0.001))
tree.prob <- predict(tree.mod, test, type = "prob")[,2]
tree.pred <- predict(tree.mod, test)
tree.cf <- confusionMatrix(tree.pred, test$Personal.Loan)

tree.perf <- round(c(tree.cf$overall[1], tree.cf$byClass[c(1,2,5,6,7)]),2)
knitr::kable(t(as.data.frame(tree.perf)), format = "simple")


## knn model
knn.mod <- train(Personal.Loan~.,
                 train,
                 method = "knn",
                 tuneGrid = expand.grid(k = 3))
knn.prob <- predict(knn.mod, test, type = "prob")[,2]
knn.pred <- predict(knn.mod, test)
knn.cf <- confusionMatrix(knn.pred, test$Personal.Loan)

knn.perf <- round(c(knn.cf$overall[1], knn.cf$byClass[c(1,2,5,6,7)]),2)
knitr::kable(t(as.data.frame(knn.perf)), format = "simple")

## random forest model
rf.mod <- train(Personal.Loan~.,
                train,
                method = "rf",
                ntry = 10,
                tuneGrid = expand.grid(mtry = 11))
rf.prob <- predict(rf.mod, test, type = "prob")[,2]
rf.pred <- predict(rf.mod, test)
rf.cf <- confusionMatrix(rf.pred, test$Personal.Loan)

rf.perf <- round(c(rf.cf$overall[1], rf.cf$byClass[c(1,2,5,6,7)]),2)
knitr::kable(t(as.data.frame(rf.perf)), format = "simple")


## XGBoost  model
xgb.mod <- train(Personal.Loan~.,
                train,
                method = "xgbTree",
                tuneLength = 1)
xgb.prob <- predict(xgb.mod, test, type = "prob")[,2]
xgb.pred <- predict(xgb.mod, test)
xgb.cf <- confusionMatrix(xgb.pred, test$Personal.Loan)

xgb.perf <- round(c(xgb.cf$overall[1], xgb.cf$byClass[c(1,2,5,6,7)]),2)
knitr::kable(t(as.data.frame(xgb.perf)), format = "simple")

# Compare the model
performace.df <- as.data.frame(rbind(glm.perf, tree.perf, knn.perf, rf.perf, xgb.perf))
knitr::kable(performace.df, format = "simple")

performace.df <- performace.df %>%
  mutate(Method = c("Logistic model", "Desicion Tree", "KNN", "Random Forest", "XGBoost")) %>%
  arrange(performace.df, desc(Accuracy)) %>%
  mutate(Method = factor(Method, levels = Method)) %>%
  pivot_longer(-Method, names_to = "Metric", values_to = "Value")

ggplot(performace.df, aes(Metric, Value, fill = Method)) +
  geom_bar(stat = "identity", position = "dodge") +
  theme_bw()

# ROC
glm.roc <- roc(test$Personal.Loan, glm.prob)
tree.roc <- roc(test$Personal.Loan, tree.prob)
knn.roc <- roc(test$Personal.Loan, knn.prob)
rf.roc <- roc(test$Personal.Loan, rf.prob)
xgb.roc <- roc(test$Personal.Loan, xgb.prob)

roc.df <- round(cbind(glm.roc$auc, tree.roc$auc, knn.roc$auc, rf.roc$auc, xgb.roc$auc), 3)
colnames(roc.df) <- c("Logistic model", "Desicion Tree", "KNN", "Random Forest", "XGBoost")
rownames(roc.df) <- "AUC"
knitr::kable(roc.df, format = "simple")

plot(rf.roc)
lines(glm.roc, col = 2)
lines(tree.roc, col = 3)
lines(knn.roc, col = 4)
lines(xgb.roc, col = 5)
legend("bottomright", c("Logistic model", "Desicion Tree", "KNN", "Random Forest", "XGBoost"),
      col = c(2,3,4,1,5), lwd = 1,  cex = 0.7)

# Model improvements
control <- trainControl(method="cv", 
                        number = 5, 
                        allowParallel = TRUE)
tunegrid <- expand.grid(.mtry = c(1:11))
rf.tune.mod <- train(Personal.Loan~.,
                     train,
                     method = "rf", 
                     metric = "Accuracy",
                     ntree = 100,
                     tuneGrid = tunegrid, 
                     trControl = control,
                     importance = TRUE)
rf.tune.mod$bestTune
plot(rf.tune.mod)
rf.tune.mod$results %>%
  select(mtry, Accuracy, Kappa) %>%
  gather(-mtry, key="metric", value="Value") %>%
  ggplot(aes(x=mtry, y=Value, color = metric, shape=metric ) ) + 
  geom_point() + 
  geom_line()
final.mod <- rf.tune.mod
varImp(rf.tune.mod)
varImpPlot(rf.tune.mod$finalModel)

var.df <- data.frame(variable = rownames(rf.tune.mod$finalModel$importance), 
                     imp = rf.tune.mod$finalModel$importance[,3])

var.df %>%
  arrange(imp) %>%
  mutate(variable = factor(variable, levels = variable)) %>%
  ggplot() +
  geom_segment(aes(x = variable, y = 0, xend = variable, yend = imp), 
               size = 1.5, alpha = 0.7) +
  geom_point(aes(x = variable, y = imp, col = variable), 
             size = 4, show.legend = F) +
  coord_flip() +
  theme_bw()

final.prob <- predict(final.mod, test, type = "prob")[,2]
final.pred <- predict(final.mod, test)
final.cf <- confusionMatrix(final.pred, test$Personal.Loan)

final.perf <- round(c(final.cf$overall[1], final.cf$byClass[c(1,2,5,6,7)]),3)


# Compare the model
performace.df1 <- as.data.frame(rbind(glm.perf, tree.perf, knn.perf, rf.perf, xgb.perf, final.perf ))
knitr::kable(performace.df1, format = "simple")

performace.df1 <- performace.df1 %>%
  mutate(Method = c("Logistic model", "Desicion Tree", "KNN", "Random Forest", "XGBoost", "Final")) %>%
  arrange(performace.df1, desc(Accuracy)) %>%
  mutate(Method = factor(Method, levels = Method)) %>%
  pivot_longer(-Method, names_to = "Metric", values_to = "Value")

ggplot(performace.df1, aes(Metric, Value, fill = Method)) +
  geom_bar(stat = "identity", position = "dodge") +
  theme_bw()

